// Reproduced from the LinkedIn "Experience" section. Dates/"Present" labels
// are copied as-is - update them if they're now stale.

export const experience = [
  {
    title: "Competitive Academic Representative",
    org: "SMA Negeri 1 Yogyakarta",
    dateRange: "Jul 2024 - Aug 2026",
    bullets: [
      "Admitted to the Astronomy Olympiad class based on placement test results - a high-performance track focused on advanced astronomy/astrophysics theory and problem-solving beyond the standard curriculum.",
      "Trained for the National Science Olympiad (OSN) and was designated as school representative at City and Province-level competition.",
    ],
  },
  {
    title: "Community Advocacy & Liturgical Communications Officer",
    org: "SMA Negeri 1 Yogyakarta",
    dateRange: "Nov 2024 - Present",
    bullets: [
      "Led the Masjid Department of the school's student Islamic organisation, coordinating daily services and events.",
      "Conducted educational sessions and provided operational support for event logistics and facility readiness.",
    ],
  },
  {
    title: "Supply Chain & Distribution Chief - GIAT 1446 H",
    org: "SMA Negeri 1 Yogyakarta",
    dateRange: "May 2025 - Jun 2025",
    bullets: [
      "Took over an unstaffed distribution division on event day, leading the end-to-end distribution workflow under tight time constraints.",
      "Directed last-mile delivery of perishable goods to beneficiary households using demographic records for equitable allocation.",
      "Restructured volunteer deployment and packaging protocols on short notice, resolving processing bottlenecks.",
      "Mobilised over IDR 40 million in community capital during the planning phase.",
    ],
  },
  {
    title: "Master of Ceremonies - GRT 1446 H",
    org: "SMA Negeri 1 Yogyakarta",
    dateRange: "Feb 2025 - Mar 2025",
    bullets: [
      "Primary MC for a religious gathering of 300+ attendees, managing schedule and program transitions.",
      "Handled financial aggregation and end-to-end procurement for an honourarium and gift to the guest speaker.",
    ],
  },
];
